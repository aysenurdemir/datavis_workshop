from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import plotly as py
import plotly.graph_objs as go

init_notebook_mode(connected=True) #do not miss this line

np.random.seed(42)
random_x = np.random.randint(1,101,100)
random_y = np.random.randint(1,101,100)

data = [go.Scatter(
    x = random_x,
    y = random_y,
    mode = 'markers',
)]
# layout = go.Layout(
#     title = 'Random Data Scatterplot', # Graph title
#     xaxis = dict(title = 'random x-values'), # x-axis label
#     yaxis = dict(title = 'random y-values'), # y-axis label
#     hovermode ='closest' # handles multiple points landing on the same vertical
# )

fig = go.Figure(data=data)
# fig = go.Figure(data=data, layout=layout)

py.offline.iplot(fig)
